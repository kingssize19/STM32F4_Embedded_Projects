/*
 * delay_us.h
 *
 *  Created on: Oct 10, 2024
 *      Author: hayat
 */

#ifndef INC_DELAY_US_H_
#define INC_DELAY_US_H_

#include "stm32f4xx_hal.h"
#include <stdint.h>

void Delay_Init(void);
void Delay_us(uint32_t us);


#endif /* INC_DELAY_US_H_ */
