#include "delay_us.h"


void Delay_Init(void)
{
	CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
	DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

void Delay_us(uint32_t us)
{
    uint32_t us_count_tick = us * (HAL_RCC_GetHCLKFreq() / 1000000); // 1 mikrosaniye başına düşen clock döngüsü
    uint32_t start_tick = DWT->CYCCNT; // Başlangıç zamanı

    while ((DWT->CYCCNT - start_tick) < us_count_tick); // Hedef süreye ulaşana kadar bekle
}
